self.assetsManifest = {
  "version": "Eyyb1ENh",
  "assets": [
    {
      "hash": "sha256-XkusTglG1UOFIVrr7yBrDQOAz2+DbUmc8mntWysBxww=",
      "url": "_content/Lebensplaner.Core/css/grundlage.css"
    },
    {
      "hash": "sha256-GxqBMdnt+XXZ3s7oHi8r9QSBL3pPSY5VAPKKYT4i5kw=",
      "url": "_content/Lebensplaner.Core/fonts/space-grotesk-500.woff2"
    },
    {
      "hash": "sha256-aFu79p+mFt8e+BhHyF/Ha+CX3fs0aP8iV75UURqzEw8=",
      "url": "_content/Lebensplaner.Core/fonts/space-grotesk-600.woff2"
    },
    {
      "hash": "sha256-NfiuxWz9XL/bA8xoczpUoLBbs2F//NX9MyutwLBFylU=",
      "url": "_content/Lebensplaner.Core/fonts/space-grotesk-700.woff2"
    },
    {
      "hash": "sha256-nbiug5P54y4XDdQ8GiGAzKt4PayXpMkMuDtRHQ4B/Gs=",
      "url": "_content/Lebensplaner.Core/js/datei.js"
    },
    {
      "hash": "sha256-s8CrXix7eqpxh0iZ5ADoHqVUOC3iP5jUyVhDsNMz3po=",
      "url": "_content/Lebensplaner.Core/js/dialog.js"
    },
    {
      "hash": "sha256-g3+0X6AHmxtFsB7pwYJDuX6cZVhmFiRjn0s/uL+0Ic4=",
      "url": "_content/Lebensplaner.Core/js/gesten.js"
    },
    {
      "hash": "sha256-d741B6yt9l5UTyE03UJSByrOzVtlBZ+iyxHG1pL6P8Q=",
      "url": "_content/Lebensplaner.Core/js/indexeddb.js"
    },
    {
      "hash": "sha256-zTEZh5lTcDivW7pxnUoqY8XmLreKwgSPPneQLLjaR2E=",
      "url": "_content/Lebensplaner.Core/js/installation.js"
    },
    {
      "hash": "sha256-5pFU/0nz9jqhZYwSRZ5ez+Eq0og2+hlJFPa/KmMFDCw=",
      "url": "_content/Lebensplaner.Core/js/teilen.js"
    },
    {
      "hash": "sha256-2RF9G/pdg7blWGy4VwlM6cD33jx7Qz4ctUhVpAnNGQg=",
      "url": "_framework/Lebensplaner.App.b3vnp66s8g.wasm"
    },
    {
      "hash": "sha256-SVJzzIdNF+6XTVRH1njlBWVXngWdwtq3g2QyMl5Bp7o=",
      "url": "_framework/Lebensplaner.Core.74mjjdz5jh.wasm"
    },
    {
      "hash": "sha256-4x9bvj8dBVyPfCUcHfEMFihUSGotZRuOKEodEsjj5do=",
      "url": "_framework/Lebensplaner.Einkauf.91vgjr6tbg.wasm"
    },
    {
      "hash": "sha256-xZPTql1DgLyUxi3yiRubGVlX59dLUJxz41fJXL1xxNQ=",
      "url": "_framework/Lebensplaner.Essen.nljw1og540.wasm"
    },
    {
      "hash": "sha256-O9fxkJkDfI2NMwVxtVRS8TEtjdj+MHYZFohL2oENwlE=",
      "url": "_framework/Lebensplaner.Haushalt.1dzfocspyc.wasm"
    },
    {
      "hash": "sha256-NecMg0wAAfTyU5H63VQFCwWQNjBMJ2Zr4M3whsL5irI=",
      "url": "_framework/Lebensplaner.Reise.jqlvxyxwoh.wasm"
    },
    {
      "hash": "sha256-TGP1ie8kcd7peo9KZ+S1B3uRADbA7Md9HA71R/K7xuA=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ksvbztdfby.wasm"
    },
    {
      "hash": "sha256-gJTuIv8UhX70+LfFD/VocVvplzdnGoL3a+8YQ5bhbso=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.gs8souk7i5.wasm"
    },
    {
      "hash": "sha256-eJYZUAo0Pf1Oph2ZKvvuyRV5rzOReqwXIckGhwe1fzQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.s7yxja10dd.wasm"
    },
    {
      "hash": "sha256-sKlc0ljsYj0miYkKYc4QscrvF85zLpABlEUAnWgTstw=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.g80u52ij8n.wasm"
    },
    {
      "hash": "sha256-NjAIjIQlITJK5e/1cNjeMLBSuW2yXbc3mfYPnlQU0WU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.ixktlrimdt.wasm"
    },
    {
      "hash": "sha256-cPFBZhC9IYk0VBEu3Lu7BDc7/DepxvRfPEGW46+Dh+U=",
      "url": "_framework/Microsoft.Extensions.Configuration.w4ckz9zukx.wasm"
    },
    {
      "hash": "sha256-2DHbveZk686EO44twwm7p16ynQLA309ZwwMZRmZSsdE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.ooj2yvgji8.wasm"
    },
    {
      "hash": "sha256-Uf2OoF4AD/nB8bEP9+Vtasx3otZscbwOarFh3Uu7bQI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.b9mcrj62ry.wasm"
    },
    {
      "hash": "sha256-Tf7Gb6fDV5ydK7ePECJC0b0p7qx8qst3QnGqZfXWtk0=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.3c4b31trca.wasm"
    },
    {
      "hash": "sha256-mbNEmfqRHcXa1eXIsnSfoKUSC1/ZdphrzRhl3iZFUjU=",
      "url": "_framework/Microsoft.Extensions.Logging.vqiumbbk2y.wasm"
    },
    {
      "hash": "sha256-Hc9A5YIXypiP2nVW0afzJORCuE6/Et8IZe7B0C2PxXo=",
      "url": "_framework/Microsoft.Extensions.Options.7f85fudcxr.wasm"
    },
    {
      "hash": "sha256-TkQ9Hsi6/hTbd0QU/u6Oevaqpf4AYYoAQNeSZQepxs8=",
      "url": "_framework/Microsoft.Extensions.Primitives.m33spxmuwm.wasm"
    },
    {
      "hash": "sha256-Xcxd+z/8v1MjYI/6IsNgJ46ifV38aKmiGyz4RR+L0ms=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.5ydn64ly88.wasm"
    },
    {
      "hash": "sha256-RbGuPO372fPqZYm1jCnkL8AiEGqHwz5w1SRblJI9qnY=",
      "url": "_framework/Microsoft.JSInterop.jia29p822m.wasm"
    },
    {
      "hash": "sha256-gmuh+z8PzN3z1Bqdh7rL2kxmWkx3UMPSxmBqG5cBPrQ=",
      "url": "_framework/System.Collections.Concurrent.mq42oyvdkr.wasm"
    },
    {
      "hash": "sha256-yuGjLwEfaNZJ/D1ak3jrXAY3uLQmo9BZNTi/1S1W8lw=",
      "url": "_framework/System.Collections.Immutable.m1tjgm2uc3.wasm"
    },
    {
      "hash": "sha256-Zng5P963Sr2E0fbkt1TKlWpBb3AzvqOmC5B4gDJ3nws=",
      "url": "_framework/System.Collections.NonGeneric.2eqo4m9rgn.wasm"
    },
    {
      "hash": "sha256-mhfmt7hqwmxTuUOz0tHoLOhyC2KHQd0J68ZD/P/NQXk=",
      "url": "_framework/System.Collections.Specialized.q47ecwz32u.wasm"
    },
    {
      "hash": "sha256-VTM4A6rX893TfDkIcQsCxcD5peBERsi2LufykTQgkPw=",
      "url": "_framework/System.Collections.r8brzid086.wasm"
    },
    {
      "hash": "sha256-RJwaEBBewVWhR61o+54CZMIPGALyt+D241EgY0vqzFk=",
      "url": "_framework/System.ComponentModel.Primitives.w76hqofemw.wasm"
    },
    {
      "hash": "sha256-dq8J8awK9XPuktnOJtQqW2rE/u/y/8SreKqS26Z/jTM=",
      "url": "_framework/System.ComponentModel.TypeConverter.yefmt7qsyn.wasm"
    },
    {
      "hash": "sha256-A3cXygK2O5szILGJVXRvAq3Ru/guTxRmqMOiy1cnmVc=",
      "url": "_framework/System.ComponentModel.j8t4mlscoa.wasm"
    },
    {
      "hash": "sha256-yN6GSsa3cJCwIQznm4lSv8OT5XMX4QRaaJ5FM/39sJ4=",
      "url": "_framework/System.Console.sb941ahwqg.wasm"
    },
    {
      "hash": "sha256-zfHj58nUrFm4kwUS7AUdbn7RK0y2JMOzgT2jx2K3M+M=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ritjampkuo.wasm"
    },
    {
      "hash": "sha256-VAItgUEBvLcUdhWi2dVGBp/lsYOLjES6nhQF93Gd1m4=",
      "url": "_framework/System.IO.Pipelines.0luqpzcwkx.wasm"
    },
    {
      "hash": "sha256-XQXD+WQJcF3nfEDP70FNCRXhQlYtKBlMuh//Hcc92lE=",
      "url": "_framework/System.Linq.3cnmb4msy7.wasm"
    },
    {
      "hash": "sha256-AlnW0l4iyjGNgX9Et2nPvFPNfqhCRkoB6U+DthEvkkk=",
      "url": "_framework/System.Memory.mmd0igxj6j.wasm"
    },
    {
      "hash": "sha256-hZFTCP8tBcyv9UhxRwlqhChDinDsUE2yM+2E1eQWDlE=",
      "url": "_framework/System.ObjectModel.71xt2g2ecm.wasm"
    },
    {
      "hash": "sha256-PrpwC3M6Oh7UR0v5eH7QA3UKa9ZPn2whh2Fi4rnZyyE=",
      "url": "_framework/System.Private.CoreLib.u1og8c71ne.wasm"
    },
    {
      "hash": "sha256-PgaqBvfoc283TMuSh9WCgId7t10QIc23HsMVk5lQj+I=",
      "url": "_framework/System.Private.Uri.eodce6l570.wasm"
    },
    {
      "hash": "sha256-5Q6RRLB1U138rk36PguY2mQJdYF23wFpfw/3vY0nQGM=",
      "url": "_framework/System.Runtime.32li60jfk8.wasm"
    },
    {
      "hash": "sha256-R9aUORxsL1Uy5IL5uONuC7aiSLohp3NX7irrSitGLh0=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.78mfkxc91d.wasm"
    },
    {
      "hash": "sha256-EtCAv8n8nbXWUJNH16d5QxTfbrvBzSNzfiMZBRA5N64=",
      "url": "_framework/System.Security.Cryptography.2zkzja4hey.wasm"
    },
    {
      "hash": "sha256-QZ85TDd+wP+tLPObVsxX9mISJq69Hv8xLNRXvQL/+sw=",
      "url": "_framework/System.Text.Encodings.Web.7menjllscu.wasm"
    },
    {
      "hash": "sha256-8zGvoSB5dGaSJWA72z5ySDRaKXX3u0UJ9VA9/pogjSU=",
      "url": "_framework/System.Text.Json.tw70il23jm.wasm"
    },
    {
      "hash": "sha256-qiqeJO/4KPbozEMZiiezy8rpq7taK52OGfASgSXz3so=",
      "url": "_framework/System.Text.RegularExpressions.u6eavgzi6w.wasm"
    },
    {
      "hash": "sha256-9sqxDqsJvThLMh0yXr9DqdM5CdG4QU8caPT6cVqABTg=",
      "url": "_framework/System.Threading.em5uvxbcig.wasm"
    },
    {
      "hash": "sha256-GBsoWgsm7nTRKlb5Lr430r1XsgW1gVH+jeoGAIS2K00=",
      "url": "_framework/System.cvgusyd4es.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-GE64+hdeg505OabV15tfdfwPA0rlVD6V32lHH8LBuUg=",
      "url": "_framework/dotnet.khuvu9slgk.js"
    },
    {
      "hash": "sha256-gQbHHzCnWx8iDOC65EKbql7bEltJkfao7lmkAbIRajw=",
      "url": "_framework/dotnet.native.puryxhmhq9.js"
    },
    {
      "hash": "sha256-pqkc+YDwRTSgmuWJlAiNJayjN0YQFu94A84NGzuA12Q=",
      "url": "_framework/dotnet.native.u31nt9bth6.wasm"
    },
    {
      "hash": "sha256-SOUHEQ3FhDAibBSR2u90NWZpoBjPuWRmH0BAATUlhJU=",
      "url": "_framework/dotnet.runtime.web2r9gqbh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-sJaHLn4KPom0LhJLPvTF+mCCyyPpjRyNGjXgu0THsSg=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-0O6xqAMKwrP1R6SkhfOBeCQEpoEJroG7Kt3xSnuFaOQ=",
      "url": "css/schale.css"
    },
    {
      "hash": "sha256-EQrVeI94UonJFbzeH+AXIlOBn+KA48+/tzVrj8XuEUU=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-4w8/22x53Qkp2XYpB/ZeZeuXyIjaQoOF8AMheZ9dzxw=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-EVYMB5Wvm1HWnhbI6rJYN8mGmMKsEdMvFZ8U1NKGjFU=",
      "url": "index.html"
    },
    {
      "hash": "sha256-cERKgvoR+CVYaye3Dl7KVZesoBrO0GHFoTM1uieN5cc=",
      "url": "js/aktualisierung.js"
    },
    {
      "hash": "sha256-nc8XXc8cVs5DJWrGNxHKoKV5TWIJ3opFXXz6M6vNke8=",
      "url": "manifest.webmanifest"
    }
  ]
};
